#ifndef Diary_H
#define Diary_H

#include <iostream>
#include <vector>
#include <string>
#include "Creature.h"

using namespace std;

class Diary
{
public:
    Creature myCreature;
    static vector <string> day;
    static void NewDay(string day);

};
#endif

