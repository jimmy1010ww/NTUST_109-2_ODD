#include "Diary.h"
#include "Creature.h"

vector<string> Diary::day;

void Diary::NewDay(string day)
{
	Diary::day.push_back(day);
}
