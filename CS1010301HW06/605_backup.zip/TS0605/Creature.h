#ifndef Creature_H
#define Creature_H

#include <iostream>
#include <vector>
#include <string>

using namespace std;

class Creature
{
public:
    
    struct log {
        string day;
        string body_part;
        int original_value;
        int changed_value;
    };

    string name;    //生物名字
    vector <string> BodyPart;   //身體部位
    vector <int> value;         //儲存身體部位的數量(跟上面的部位共用INDEX)
    vector <log> mylog;         //儲存log
    string start_day;           //起始日
    int changeIndex;            //共用更改index

    Creature(string name); 
    //Contains a creature named name.
    Creature(string name, Creature in);
    //A creature that contains the same information as the base of each body part.

    void operator=(int in);
    void operator+=(int in);
    void operator-=(int in);

    void PrintStatus(); //Prints the value of each body part of the organism.
    void PrintLog();    //Prints the log information of the creature on a Diary basis since it was collected.

    Creature& operator[](string i);
};
#endif