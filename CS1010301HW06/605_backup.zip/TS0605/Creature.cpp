#include "Creature.h"
#include "Diary.h"
//#define DEBUG

Creature::Creature(string name)
{
	Creature::name = name;
	start_day = Diary::day[Diary::day.size() - 1];
}

Creature::Creature(string name, Creature in)
{
	Creature::name = name;
	start_day = Diary::day[Diary::day.size() - 1];
	BodyPart.assign(in.BodyPart.begin(), in.BodyPart.end());
	value.assign(in.value.begin(), in.value.end());
}

void Creature::operator=(int in)
{
	//<name>'s <body_part> appeared (<original_value> -> <changed_value>)
	//string tmp_message = name + "'s " + BodyPart[changeIndex] + " appeared (" + to_string(original_value) + " -> " + to_string(changed_value) + ")";
	log tmp_log = { Diary::day[Diary::day.size() - 1],BodyPart[changeIndex],value[changeIndex],in};
	value[changeIndex] = in;
	mylog.push_back(tmp_log);
}

void Creature::operator+=(int in)
{
	//< name>'s <body_part> increased (<original_value> -> <changed_value>)
	//string tmp_message = name + "'s " + BodyPart[changeIndex] + " increased (" + to_string(original_value) + " -> " + to_string(changed_value) + ")";
	if (in != 0)
	{
		int original_value = value[changeIndex];
		value[changeIndex] = value[changeIndex] + in;
		log tmp_log = { Diary::day[Diary::day.size() - 1],BodyPart[changeIndex],original_value, value[changeIndex] };
		mylog.push_back(tmp_log);
	}
	
}

void Creature::operator-=(int in)
{
	//<name>'s <body_part> decreased (<original_value> -> <changed_value>)
	//string tmp_message = name + "'s " + BodyPart[changeIndex] + " decreased (" + to_string(original_value) + " -> " + to_string(changed_value) + ")";
	if (in != 0)
	{
		int original_value = value[changeIndex];
		value[changeIndex] = value[changeIndex] - in;
		log tmp_log = { Diary::day[Diary::day.size() - 1],BodyPart[changeIndex],original_value, value[changeIndex] };
		mylog.push_back(tmp_log);
	}
}


void Creature::PrintStatus()
{
	cout << name << "'s status:" << endl;
	int print_flag = 1;
	for (size_t i = 0; i < BodyPart.size(); i++)
	{
		if (value[i] > 0)
		{
			cout << BodyPart[i] << " * " << value[i] << endl;
		}
		else
		{
			print_flag = 0;
		}
	}
	cout << endl;
}

void Creature::PrintLog()
{
	cout << name << "'s log:" << endl;
	int start_index = 0;
	for (size_t i = 0; i < Diary::day.size(); i++)
	{
		if (Diary::day[i] == start_day)
		{
			start_index = i;
		}
	}

	string order[3] = { "appeared","increased","decreased" };
	string last_day = "";	
	for (size_t i = start_index; i < Diary::day.size(); i++)
	{
		int print_once = 0;
		for (size_t j = 0; j < mylog.size(); j++)
		{
			if (Diary::day[i] == mylog[j].day)
			{
				if (!print_once)
				{
					cout << "Day " << Diary::day[i] << endl;
					print_once = 1;
				}

				int judge_result = 0;
				if (mylog[j].changed_value > mylog[j].original_value && mylog[j].original_value == 0)
				{
					judge_result = 0;
				}
				else if (mylog[j].changed_value < mylog[j].original_value)
				{
					judge_result = 2;
				}
				else if (mylog[j].changed_value == mylog[j].original_value)
				{
					judge_result = 1;
				}
				string log_message = name + "'s " + mylog[j].body_part + " " + 
				order[judge_result] + " (" + to_string(mylog[j].original_value) + " -> " + to_string(mylog[j].changed_value) + ")";
				cout << log_message << "." << endl;
				last_day = mylog[j].day;
			}
			else
			{
				if (!print_once)
				{
					cout << "Day " << Diary::day[i] << endl;
					print_once = 1;
				}
			}
		}
	}
	cout << endl;
}

//obtain
/*
	Obtain the specified body part of Creature. (Overload operator [])
	For example: c["leg"]: return to the body part of Creature c named "leg".
*/

Creature& Creature::operator[](string in)
{
	for (size_t i = 0; i < BodyPart.size(); i++)
	{
		if (BodyPart[i] == in)
		{
			changeIndex = i;
			return *this;
		}
	}

	BodyPart.push_back(in);
	value.push_back(0);
	changeIndex = value.size() - 1;
	return *this;
}